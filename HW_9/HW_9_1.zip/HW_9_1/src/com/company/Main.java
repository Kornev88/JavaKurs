package com.company;

public class Main {

    public static void main(String[] args) {

        String[] names = {"Ira", "Dima", "Marie", "Julia", "Andrey"};
         printNames(names);

    }

    public static void printNames(String[] names) {
        for (int i = 0; i < names.length; i++) {


            if (names[i].length() <= 5) {
                System.out.println(names[i]);
            }
        }
    }
}