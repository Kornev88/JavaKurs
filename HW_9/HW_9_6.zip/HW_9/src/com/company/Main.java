package com.company;

public class Main {

    public static void main(String[] args) {


       int[] numbers1 = {10, 3, 3, 5, -9};
        int max = numbers1[0];
        int indexMax=0;

        for (int i = 0; i < numbers1.length; i++) {
            int number = numbers1[i];
            if (max<number){
                 max =number;
                 indexMax=i;
            }
        }
        System.out.println(indexMax);

    }


}
