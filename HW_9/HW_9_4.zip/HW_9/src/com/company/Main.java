package com.company;

public class Main {

    public static void main(String[] args) {
        int[] numbers1 = {10,3,3,5,-9};
        int sum =0;

        for (int i=0; i< numbers1.length; i++){
            sum += numbers1[i];
        }
        for (int i=0; i< numbers1.length;i++){
            System.out.println(numbers1[i]);
        }
        System.out.println("Сумма "+sum);
    }
}
