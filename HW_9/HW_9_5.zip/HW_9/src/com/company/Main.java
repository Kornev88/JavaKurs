package com.company;

public class Main {

    public static void main(String[] args) {


        int[] numbers1 = {10, 3, 3, 5, -9};
        int max = numbers1[0];

        for (int i = 0; i < numbers1.length; i++) {
            if (numbers1[i] > max){
                 max = numbers1[i];
            }
        }
        System.out.println(max);

    }


}
