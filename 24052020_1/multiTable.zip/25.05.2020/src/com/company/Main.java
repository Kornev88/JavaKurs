package com.company;

public class Main {

    public static void main(String[] args) {
      multiTable();
    }

    public static void multiTable() {
        int a;
        int b;
        int c = 0;
        for (a = 1; a < 10; a++) {
            for (b = 1; b < 10; b++) {
                c = a * b;
                System.out.print(c+" ");
            }
            System.out.println();
        }

    }

}
