package com.company;

public class Main {

    public static void main(String[] args) {

        int a = 10;
        int b = 7;

        int c = a-b;

        System.out.println("a("+a+")-b("+b+")="+c);

        int d = a*b;

        System.out.println("a("+a+")*b("+b+")="+d);
    }


}
