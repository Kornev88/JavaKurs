package com.company;

public class Main {

    public static void main(String[] args) {
       printLineNtimes("Hello",3);
    }
  public static void printLineNtimes(String a, int b){
        int i=0;
        while (i<3){
            System.out.println("Hello");
            i++;
        }
  }
}
