package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println(checkDiv(35,5));
        System.out.println(checkDiv(41,2));
        System.out.println(checkDiv(6,0));


    }
    public static boolean checkDiv(int a, int b){
        return ((b!=0) &&(a%b)==0) ;


    }

}
